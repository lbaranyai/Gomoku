Gomoku - logical strategy game
=====================================================
Developer: lbaranyai@github


1. Install

Download ZIP package and extract to any folder. The
software is ready to play. Available at:

https://github.com/lbaranyai/Gomoku

Content is:
- gomoku.exe			binary
- borlndmm.dll			dynamic library
- cc32240mt.dll			dynamic library

2. Requirements

Software is running on Windows(TM) computers. Binary
is compiled to 32 bit systems, it is compatible from
Windows XP but more recent version is recommended.

The game is tiny program, using only 2.5 MB memory and
4 MB disk space.

3. Liability

Software was tested to work as expected but provided
AS IS. Developer cannot guarantee profit or special
advantage, neither liable for damages or loss of profit
caused by modification or misuse. Anyone can use free
and also check its source code, compile his/her own
version.

4. License

This software was created for fun, not for profit.
Anyone can use free according to the 

Creative Commons Zero 1.0
https://creativecommons.org/publicdomain/zero/1.0/
